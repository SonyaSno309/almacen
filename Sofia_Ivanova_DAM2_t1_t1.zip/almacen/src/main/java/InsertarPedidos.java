import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertarPedidos {

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO Pedidos (id_producto, descripcion, precio_total) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            Object[][] pedidos = {
                    {1, "Pedido de 10 unidades de producto 1", 99.90},
                    {2, "Pedido de 5 unidades de producto 2", 99.95},
                    {3, "Pedido de 20 unidades de producto 3", 299.8}
            };

            for (Object[] pedido : pedidos) {
                pstmt.setInt(1, (int) pedido[0]);
                pstmt.setString(2, (String) pedido[1]);
                pstmt.setDouble(3, (double) pedido[2]);
                pstmt.executeUpdate();
            }

            System.out.println("Pedidos insertados correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
