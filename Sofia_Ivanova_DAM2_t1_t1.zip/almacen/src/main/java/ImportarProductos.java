import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

public class ImportarProductos {

    public static void main(String[] args) {
        String jsonUrl = "https://dummyjson.com/products";

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(jsonUrl).openConnection();
            connection.setRequestMethod("GET");

            InputStreamReader reader = new InputStreamReader(connection.getInputStream());
            JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
            JsonArray productsArray = jsonObject.getAsJsonArray("products");

            List<Product> products = new Gson().fromJson(productsArray, new TypeToken<List<Product>>() {}.getType());

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO Productos (nombre, descripcion, cantidad, precio) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);

                for (Product product : products) {
                    pstmt.setString(1, product.getName());
                    pstmt.setString(2, product.getDescription());
                    pstmt.setInt(3, product.getStock());
                    pstmt.setDouble(4, product.getPrice());
                    pstmt.executeUpdate();
                }

                System.out.println("Productos importados exitosamente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static class Product {
        private String title;
        private String description;
        private int stock;
        private double price;

        // Getters
        public String getName() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public int getStock() {
            return stock;
        }

        public double getPrice() {
            return price;
        }
    }
}
