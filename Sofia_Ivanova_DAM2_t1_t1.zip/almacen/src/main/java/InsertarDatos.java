import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertarDatos {

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            String sqlEmpleados = "INSERT INTO Empleados (nombre, apellidos, correo) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sqlEmpleados);

            pstmt.setString(1, "Marta");
            pstmt.setString(2, "Rodriguez");
            pstmt.setString(3, "marta@gmail.com");
            pstmt.executeUpdate();

            pstmt.setString(1, "Sofia");
            pstmt.setString(2, "Ivanova");
            pstmt.setString(3, "sofia@gmail.com");
            pstmt.executeUpdate();

            System.out.println("Empleados insertados correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
