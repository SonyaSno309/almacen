import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InsertarProductosFav {

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT id FROM Productos WHERE precio > 1000";
            PreparedStatement pstmtQuery = conn.prepareStatement(query);
            ResultSet rs = pstmtQuery.executeQuery();

            String insertFav = "INSERT INTO Productos_Fav (id_producto) VALUES (?)";
            PreparedStatement pstmtInsert = conn.prepareStatement(insertFav);

            while (rs.next()) {
                int idProducto = rs.getInt("id");

                pstmtInsert.setInt(1, idProducto);
                pstmtInsert.executeUpdate();
            }

            System.out.println("Productos favoritos insertados correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
