import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class MostrarDatos {

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM Empleados";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String correo = rs.getString("correo");

                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Apellidos: " + apellidos + ", Correo: " + correo);
            }


            String sqlProductos = "SELECT * FROM Productos";
            ResultSet rsProductos = stmt.executeQuery(sqlProductos);

            System.out.println("\nProductos:");
            while (rsProductos.next()) {
                int id = rsProductos.getInt("id");
                String nombre = rsProductos.getString("nombre");
                String descripcion = rsProductos.getString("descripcion");
                int cantidad = rsProductos.getInt("cantidad");
                double precio = rsProductos.getDouble("precio");

                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Descripción: " + descripcion + ", Cantidad: " + cantidad + ", Precio: " + precio);
            }


            String sqlPedidos = "SELECT * FROM Pedidos";
            ResultSet rsPedidos = stmt.executeQuery(sqlPedidos);

            System.out.println("\nPedidos:");
            while (rsPedidos.next()) {
                int id = rsPedidos.getInt("id");
                int idProducto = rsPedidos.getInt("id_producto");
                String descripcion = rsPedidos.getString("descripcion");
                double precioTotal = rsPedidos.getDouble("precio_total");

                System.out.println("ID: " + id + ", ID Producto: " + idProducto + ", Descripción: " + descripcion + ", Precio Total: " + precioTotal);
            }


            String sqlProductosMenor600 = "SELECT * FROM Productos WHERE precio < 600";
            ResultSet rsProductosMenor600 = stmt.executeQuery(sqlProductosMenor600);

            System.out.println("\nProductos con precio inferior a 600€:");
            while (rsProductosMenor600.next()) {
                int id = rsProductosMenor600.getInt("id");
                String nombre = rsProductosMenor600.getString("nombre");
                double precio = rsProductosMenor600.getDouble("precio");

                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Precio: " + precio);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
